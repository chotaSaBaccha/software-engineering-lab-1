
import random
import pygame
from game.block import Block


class GameEngine:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.block_height = 28
        self.base_width = 180

        self.font_title = pygame.font.SysFont(None, 38)
        self.font_hud = pygame.font.SysFont(None, 28)
        self.font_big = pygame.font.SysFont(None, 46)

        self.reset()

    def get_color(self, index):
        palette = [
            (230, 75, 75),
            (240, 140, 45),
            (245, 210, 50),
            (60, 195, 110),
            (50, 150, 240),
            (165, 80, 225),
        ]
        return palette[index % len(palette)]

    def reset(self):
        self.score = 0
        self.game_over = False

        base_x = (self.width - self.base_width) // 2
        base_y = self.height - 60

        base_block = Block(
            base_x, base_y,
            self.base_width, self.block_height,
            self.get_color(0), speed=0
        )

        self.stack = [base_block]
        self.spawn_active_block()

    def spawn_active_block(self):
        top_block = self.stack[-1]
        next_y = top_block.y - self.block_height - 4
        speed = min(10.0, 4.5 + len(self.stack) * 0.35)
        color = self.get_color(len(self.stack))

        start_x = (
            25 if random.choice([True, False])
            else self.width - 25 - top_block.width
        )

        self.active_block = Block(
            start_x, next_y,
            top_block.width, self.block_height,
            color, speed=speed
        )

    def drop_block(self):
        if self.game_over:
            return

        top_block = self.stack[-1]
        active = self.active_block

        # Calculate the horizontal intersection.
        left = max(active.x, top_block.x)
        right = min(
            active.x + active.width,
            top_block.x + top_block.width
        )
        overlap = right - left

        # BUG FIX: A complete miss ends the game.
        if overlap <= 0:
            self.game_over = True
            return

        # Keep only the overlapping part of the block.
        new_block = Block(
            left,
            active.y,
            overlap,
            self.block_height,
            active.color,
            speed=0
        )

        self.stack.append(new_block)
        self.score += 1

        # Shift the tower down when it grows too high.
        if new_block.y < 180:
            shift_amount = self.block_height + 4
            for block in self.stack:
                block.y += shift_amount

        self.spawn_active_block()

    def handle_event(self, event):
        if self.game_over:
            # BUG FIX: Both Space and R restart the game.
            if (
                event.type == pygame.KEYDOWN
                and event.key in (pygame.K_SPACE, pygame.K_r)
            ):
                self.reset()
            elif (
                event.type == pygame.MOUSEBUTTONDOWN
                and event.button == 1
            ):
                self.reset()

            return

        if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
            self.drop_block()
        elif (
            event.type == pygame.MOUSEBUTTONDOWN
            and event.button == 1
        ):
            self.drop_block()

    def update(self):
        if not self.game_over:
            self.active_block.update(self.width)

    def render(self, screen):
        screen.fill((24, 27, 36))

        title_surf = self.font_title.render(
            "Skyscraper Stack", True, (245, 245, 245)
        )
        screen.blit(
            title_surf,
            (self.width // 2 - title_surf.get_width() // 2, 16)
        )

        score_surf = self.font_hud.render(
            f"Height: {self.score}", True, (255, 220, 80)
        )
        screen.blit(
            score_surf,
            (self.width // 2 - score_surf.get_width() // 2, 54)
        )

        for block in self.stack:
            block.render(screen)

        if not self.game_over:
            self.active_block.render(screen)

        if self.game_over:
            overlay = pygame.Surface(
                (self.width, self.height), pygame.SRCALPHA
            )
            overlay.fill((0, 0, 0, 195))
            screen.blit(overlay, (0, 0))

            over_surf = self.font_big.render(
                "TOWER COLLAPSED!", True, (240, 75, 75)
            )
            screen.blit(
                over_surf,
                (
                    self.width // 2 - over_surf.get_width() // 2,
                    self.height // 2 - 40
                )
            )

            final_surf = self.font_hud.render(
                f"Final Height: {self.score}",
                True,
                (255, 255, 255)
            )
            screen.blit(
                final_surf,
                (
                    self.width // 2 - final_surf.get_width() // 2,
                    self.height // 2 + 10
                )
            )

            restart_surf = self.font_hud.render(
                "Press [Space] or [R] to Play Again",
                True,
                (200, 200, 200)
            )
            screen.blit(
                restart_surf,
                (
                    self.width // 2 - restart_surf.get_width() // 2,
                    self.height // 2 + 50
                )
            )
